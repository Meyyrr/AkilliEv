package com.example.akilliev;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class AkilliKilitActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_akilli_kilit);

        // Action Bar'ı etkinleştir ve Up butonunu göster
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        // Up butonuna basıldığında geri dön
        onBackPressed();
        return true;
    }
}
